const countryArray = ["Haiti", "France", "United States", "Belgium", "Canada", "Jamaica", "Mexico", "Brazil", "Nigeria"];



function genere(table) {
    let monUl = document.getElementById('monUL')

    let monMap = new Map()

    for (let i = 0; i < table.length; i++) {

        let li = document.createElement('li')
        li.setAttribute('name','liName')
        //li.setAttribute('value',`${countryArray[i]}`)
        let input = document.createElement('input')
        input.setAttribute('type', 'checkbox')
        input.setAttribute('name', 'checkbox')
        li.append(input)
        //input.setAttribute('id',`monli${i}`)
        li.setAttribute('id', `monli${i}`)
        let tempon = monMap.set(`monli${i}`, countryArray[i])
        let value = tempon.get(`monli${i}`)
        input.setAttribute('value',`${value}`)
        li.append(value)
        monUl.append(li)
        //console.log(li)
    }
}
(genere(countryArray))

let form =document.querySelector('form');
//console.log(form)
form.addEventListener('submit',(event)=>{
    event.preventDefault()
    let affichage2=document.createElement('div')
    affichage2.setAttribute('id','affichage')
    let data =new FormData(form)
    let choix=(data.get('checkbox'))
    const nodeChoices =
    form.querySelectorAll('input[name=checkbox]:checked')
     let choices = []
     // rekipere chak valè pou chak nod ki kwoche
     for(let i = 0; i<nodeChoices.length;i++){
     choices.push( nodeChoices[i].value )
     }
     
    let affichage =document.getElementById('affichage')
      affichage.innerText=`${choices}`
      //affichage=affichage.remove()
})




