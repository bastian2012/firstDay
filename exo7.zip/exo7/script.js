test = (str) => {
    let bool = true
    for (let i = 0; i < str.length; i++) {
        if (Number(str[i])) {
            continue;
            }
        else
        {
            bool = false
            break
        }
            
    }
    return bool;
}

carectereSpeciaux = (str) => {
    let bool = true
    let tab = '!@#$%^&*()_+=<>?|{}[]`~,./;\'';

    for (let i = 0; i < str.length; i++) {
        if (tab.includes(str[i])) {
            bool = false
            break
        }
        else
            continue;
    }
    return bool;
}


// let champ=document.getElementById('champ')
// champ.addEventListener('input', (event) => {
//     const incorrect = document.getElementById('incorrect')
//     let tempon = event.target.value
     
    


     
// })
 

champ.addEventListener('input', (event) => {
    const incorrect = document.getElementById('incorrect')
    let tempon = event.target.value
    if (tempon.length == 0){
        incorrect.innerText = '*Required field'
        incorrect.style.cssText = 'color:#f44336'
        champ.style.cssText = 'border: red solid 2px;border-radius:5px'
    }
    else if (!test(tempon)) {
        incorrect.innerText = '*no letter'
        incorrect.style.cssText = 'color:#f44336'
        champ.style.cssText = 'border:red solid 2px;border-radius:5px'
    }
    else if (!carectereSpeciaux(tempon)) {
        incorrect.innerText = '*no special caracter'
        incorrect.style.cssText = 'color:#f44336'
        champ.style.cssText = 'border:red solid 2px;border-radius:5px'
    }

    else if (tempon.length!=8) {
        incorrect.innerText = '*incorrect legth'
        incorrect.style.cssText = 'color:#f44336'
        champ.style.cssText = 'border:red solid 2px;border-radius:5px'
    }



    else {
        champ.style.cssText = 'border-radius:0px'
        incorrect.style.cssText = 'display:none'
         
    }
})